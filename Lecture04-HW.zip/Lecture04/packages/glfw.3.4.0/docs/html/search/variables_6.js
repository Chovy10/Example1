var searchData=
[
  ['reallocate_0',['reallocate',['../struct_g_l_f_wallocator.html#af5a674af9e170095b968f467233437be',1,'GLFWallocator']]],
  ['red_1',['red',['../struct_g_l_f_wgammaramp.html#a2cce5d968734b685623eef913e635138',1,'GLFWgammaramp']]],
  ['redbits_2',['redBits',['../struct_g_l_f_wvidmode.html#a6066c4ecd251098700062d3b735dba1b',1,'GLFWvidmode']]],
  ['refreshrate_3',['refreshRate',['../struct_g_l_f_wvidmode.html#a791bdd6c7697b09f7e9c97054bf05649',1,'GLFWvidmode']]]
];
